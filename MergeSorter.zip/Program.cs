﻿using System;

namespace MergeSorter
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Введите чисело элементов последовательности от 1 до 255");
            string elementCount = Console.ReadLine();

            byte elem_nums;
            while (!Byte.TryParse(elementCount, out elem_nums))
            {
                Console.WriteLine("Введено недопустимое значение. Введите число элементов последовательности");
                elementCount = Console.ReadLine();
            }

            int[] mas = new int[elem_nums];
            Console.WriteLine($"Введите {elem_nums} натуральных чисел.");
            

            for (int i = 0; i < mas.Length; i++)
            {
                Console.Write("{0}-е число: ", i + 1);
                string elementString = Console.ReadLine();
                int element;
                while (!Int32.TryParse(elementString, out element))
                {
                    Console.WriteLine("Введите целое число. {0}-е число: ", i + 1);
                    elementString = Console.ReadLine();
                }

                mas[i] = element;
            }

            Sorter sorter = new Sorter();

            Console.WriteLine(string.Join(",", sorter.Sort(mas)));
            Console.ReadKey();

        }

    }
}
